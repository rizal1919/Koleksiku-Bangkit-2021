
console.log("Selamat Anda berhasil menggunakan JavaScript pada Website")

alert("Hai, Salam Kenal!")

let caption = document.querySelector("#ganti");
caption.innerHTML = '<em>Spread Love, Always Support</em>';